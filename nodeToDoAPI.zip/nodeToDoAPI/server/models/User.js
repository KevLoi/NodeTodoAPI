var mongoose = require('mongoose');

// Model for users

// Users
// email - require it - trim it - set type=string - set minlength to 1 
var User = mongoose.model('user', {
	email: {
		required: true,
		trim: true,
		type: String,
		minlength: 1
	}
});


// this is required in order to be able to use the User model
module.exports = {User};