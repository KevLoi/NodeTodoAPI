# nodeCourse2ToDoAPI

This is kind of like a template database.
It saves todos into the database, and users as well, but different lists.
Uses NoSQL
Download mongoDB, and robo 3T to connect and test out the server.
In order to run the program you run 'npm server/server.js' in the nodeToDoAPI folder
I left comments on each file explaining as much as I could.
If you are confused about what some process does feel free to shoot me a message on slack or trello 
Also I will leave my account to udemy so you can watch videos on it as well and learn if my explanation is not enough 

URL: udemy.com
Email: j.kevnloi@gmail.com
Password: Warriors3030
The course is called "The Complete Node.js Course (2nd Edition)"
Section is MongoDB, mongoose, and REST APIs 
This is where I followed steps to create this mongo database
Look for the video where it teaches you how to set up mongodb and robomongo, and you should be good to go 
